package com.paypal.core;

public interface Authorization {
	String authorizationString();
}





